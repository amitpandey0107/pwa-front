// LOADING,
// ERROR,
// SUCCESS,
// RELOADING,
// NONE

export const LOADING ="LOADING";
export const ERROR ="ERROR";
export const SUCCESS ="SUCCESS";
export const RELOADING ="RELOADING";
export const NONE ="NONE";